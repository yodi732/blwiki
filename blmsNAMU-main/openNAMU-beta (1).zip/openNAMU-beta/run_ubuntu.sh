chmod +x ./route_go/bin

pip3 install --upgrade -r requirements.txt
python3 app.py